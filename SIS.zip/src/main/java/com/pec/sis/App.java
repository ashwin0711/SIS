package com.pec.sis;

public class App 
{
    @SuppressWarnings("static-access")
	public static void main( String[] args )
    {
        StudentinformationSystem app = new StudentinformationSystem();
        app.StudentInfo();
    }
    
}
